Press INSERT to open/close menu :)

MANUALMAP RECOMMENDED

installing configs:
All configs go into Documents/FTP