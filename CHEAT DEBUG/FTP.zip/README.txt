installing configs:
All configs go into Documents/FTP