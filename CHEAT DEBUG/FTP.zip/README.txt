installing configs:
All configs go into Documents/FTP

menu key is INSERT

please post all issues to the github issues page :)