Press INSERT to open/close menu :)

installing configs:
All configs go into Documents/FTP